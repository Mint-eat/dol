// WLI 专属身体刻印数据
// 所有刻印属于 "Ivory Wraith"，类型为文字（type: "text"），非情色内容

/** @param {number} index @param {string} writing @returns {object} */
const makeWliBrand = (index, writing) => ({
	index,
	writing,
	type: "text",
	arrow: 0,
	special: "Ivory Wraith",
	gender: "n",
	lewd: 0,
	degree: 0,
});

const W_BRAND = (text) => text;

setup.bodywritingwli = {
	reflection:    makeWliBrand(1,  W_BRAND("倒影")),
	manifestation: makeWliBrand(2,  W_BRAND("显现")),
	pearl:         makeWliBrand(3,  W_BRAND("珍珠")),
	promise:       makeWliBrand(4,  W_BRAND("誓言")),
	memory:        makeWliBrand(5,  W_BRAND("记忆")),
	droplet:       makeWliBrand(6,  W_BRAND("水滴")),
	graverobber:   makeWliBrand(7,  W_BRAND("盗墓者")),
	vulture:       makeWliBrand(8,  W_BRAND("秃鹫")),
	forsaker:      makeWliBrand(9,  W_BRAND("遗弃者")),
	accomplice:    makeWliBrand(10, W_BRAND("同谋")),
	asone:         makeWliBrand(11, "如二，合而为一。"),
	oathbreaker:   makeWliBrand(12, W_BRAND("背誓者")),
};
