// WLI (Wraith Love Interest) 模组核心初始化
// 挂载到全局 window.W 和 window.WOpts 以便 Twee 代码访问

const WLI = {};

Object.defineProperty(window, "W",    { get: () => WLI });
Object.defineProperty(window, "WOpts", { get: () => State.variables.wli.cfg });
