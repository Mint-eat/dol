// WLI 工具函数集合
// 所有函数挂载在 W（WLI 对象）上，通过 window.W 全局访问

/** Wraith 视为"愤怒"状态的最低稳定度阈值 */
W.minStability = 50;

/**
 * 统计玩家与 Ivory Wraith 所生的、存活在家中的苍白婴儿数量
 * @returns {number}
 */
W.countPaleBabies = () => {
	Wikifier.wikifyEval(
		"<<getChildrenIds `{location:'home', father:'Ivory Wraith'}`>>"
	);
	return T.childrenIds.length;
};

/**
 * 统计容器中含有 "Pale" 字样的生物数量
 * @returns {number}
 */
W.countPaleCritters = () => {
	let total = 0;
	for (const key of V.container.list) {
		const container = V.container[key];
		if (container.count > 0) {
			for (const critter of Object.values(container.creatures)) {
				if (critter.creature.includes("Pale")) total++;
			}
		}
	}
	return total;
};

/**
 * 统计皮肤上属于 Ivory Wraith 的特殊刻印数量
 * @returns {number}
 */
W.countSpecialTattoos = () => {
	let total = 0;
	for (const bw of Object.values(V.skin)) {
		if (bw.special === "Ivory Wraith") total++;
	}
	return total;
};

/**
 * 判断 Wraith 当前是否处于愤怒状态
 * 触发条件：haunt 状态、玩家持有项链、或后代死亡/被出售
 * @returns {boolean}
 */
W.wraithIsAngry = () => {
	return (
		V.wraith.state === "haunt" ||
		V.necklaceThief === "player" ||
		["dead", "sold"].includes(V.wraith.offspring)
	);
};

/**
 * brandMethod - 根据设置返回当前烙印类型字符串
 * @returns {"tattoo"|"magic"|undefined}
 */
W.brandMethod = () => {
	switch (WOpts.bodywritinglvl) {
		case 1: return "tattoo";
		case 2: return "magic";
	}
};
